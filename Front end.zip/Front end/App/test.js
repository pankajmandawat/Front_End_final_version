arr_1=[{name :"A1",color:"red"},{name :"B1",color:"Green"},{name :"C1",color:"Yellow"},
{name :"D1",color:"Blue"},{name :"E1",color:"blue"}]


for (let array_1 of arr_1){

    
    if(array_1.color=="Blue")    {
        var index =arr_1.indexOf(array_1)
    }
}
console.log(arr_1[index].color)

console.log(index)