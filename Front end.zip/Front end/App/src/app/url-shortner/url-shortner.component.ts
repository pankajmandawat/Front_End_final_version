import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-url-shortner',
  templateUrl: './url-shortner.component.html',
  styleUrls: ['./url-shortner.component.css']
})
export class UrlShortnerComponent implements OnInit {
  error: any
  constructor(private http: ServiceService, private formBuilder: FormBuilder) { }
  boxForm: any
  // dummy array created for testing purpose. Which will be replaced after user login
  boxArray: any[] = [{ name: "A1", color: "Blue" }, { name: "B1", color: "White" }, { name: "C1", color: "White" },
  { name: "D1", color: "White" }, { name: "E1", color: "White" }]
  valid: any;
  increament: any
  userName: any
  indexOfBlue: any
  obj_update :any
  ngOnInit(): void {
    this.userName = sessionStorage.getItem("userName")
    this.http.getBox(this.userName).subscribe((response) => { 
      // replacing the dummy array after user login
      this.boxArray=response.progress
    })
    this.boxForm = this.formBuilder.group({
      boxName: ['', Validators.required]
    })
  }

  //Mthod for calling function for getting box
  Submit() {
    for (let array_1 of this.boxArray) {

      if (array_1.color == "Blue") {
        this.indexOfBlue = this.boxArray.indexOf(array_1)
      }
    }
    if (this.boxArray[this.indexOfBlue].name == this.boxForm.value.boxName) {

       this.obj_update ={ "username" : sessionStorage.getItem("userName"),
        "progress" : this.boxArray[this.indexOfBlue].name,
        "next_progress" : this.boxArray[this.indexOfBlue+1].name
    }
      this.http.updateUser(this.obj_update).subscribe((response) => {
        if (response) {
          this.ngOnInit()
        }
      })

    }

  }
}
